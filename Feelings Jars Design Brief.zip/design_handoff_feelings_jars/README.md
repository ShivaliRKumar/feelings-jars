# Handoff: Feelings Jars

## Overview
A personal, playful web app for a couple (Shivali & Vrushab) to log emotional moments into "jars" filled with colored balls, plus an apology-fund "piggy bank" widget. Single-tenant, no login — just the two of them.

## About the Design Files
The files in this bundle (`Feelings Jars.dc.html`, `Jar.dc.html`) are **design references** built in an HTML prototyping tool (Design Components — a proprietary streaming-template format, NOT React/JSX source you can import directly). Treat them as an interactive spec: exact colors, spacing, copy, and behavior are final, but the markup itself should not be copy-pasted as-is into a real codebase.

**Task:** recreate this design in the target codebase's existing environment (React Native, React web, SwiftUI, etc.) using its established component patterns — or, if no environment exists yet, choose the most appropriate stack (a simple React + localStorage web app is a good fit given the scope) and implement fresh.

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and interaction behavior below are final and should be matched closely. The hand-drawn "cozy scrapbook" shapes (jar, piggy bank) are built from plain CSS boxes/circles/clip-paths, not images — feel free to reimplement them as SVG or CSS in the target stack, matching the described proportions.

## Screens / Views
This is a single-page app with two person tabs and several modals. There are no separate routes.

### 1. Main screen
- **Purpose:** Landing view. Shows the active person's two jars, entry-viewing buttons, and (Shivali only) the piggy bank.
- **Layout:** Centered column, max content width ~900px, generous padding (36px top/bottom, 20px sides). Two soft radial-gradient blobs decorate the top-right and bottom-left corners of the page (decorative only, `pointer-events:none`).
- **Header:** "Feelings Jars" in Caveat (handwritten script font), 64px, weight 700, color `#3d2c22`. Subtitle below: "a little jar for the little moments", Quicksand 15px, color `#8a7362`.
- **Tabs:** Two buttons, "Shivali" and "Vrushab", centered, gap 10px. Caveat 22px bold. Active tab: colored background (its palette's `tabAccent`), lifted `translateY(-4px)`, drop shadow `0 4px 0 rgba(61,44,34,0.15)`. Inactive: cream background `#fff9f0`, opacity 0.72, no lift. Shivali's tab is active by default on load.
- **Jars row:** Two jars side by side, gap 58px, wrapping on narrow screens. Happy jar rotated -2deg, Hurtful jar rotated +2deg (scrapbook "tilted photo" feel).
- **Entry buttons:** Below jars, two pill buttons "View happy entries" / "View hurtful entries", Caveat 18px bold, cream background, 2.5px dark border.
- **Piggy Bank card:** Shivali's tab only (see below).

### 2. Jar component (reused ×2 per tab)
- **Purpose:** Visualize one jar's entries as balls; button to add a new entry.
- **Structure (top to bottom):**
  - Lid: 88×20px rounded rect, 4px dark border, background = jar's accent color.
  - Neck: 64×16px, side borders only (creates a "glass jar neck" illusion), semi-transparent white fill.
  - Body: 280×360px, 5px dark border (`#3d2c22`), asymmetric border-radius `30px 30px 60px 60px / 30px 30px 46px 46px` (rounder at the bottom, mason-jar taper). Background is a layered glass gradient + a subtle vertical-ridge `repeating-linear-gradient` (mason-jar ribbing, 24px period). Inset shadow for depth + drop shadow below.
    - Glass shine: a soft vertical white gradient strip near the left edge, 22px wide, 85% of body height, `pointer-events:none`.
    - **Label tag**: pinned near the top-center of the body (not below it), rotated -3deg, small dark "pin" dot above it. Pill shape, background = accent color, text = jar name ("Happy"/"Hurtful"), Caveat 20px bold.
    - **Balls area**: absolutely inset (16px top, 14px sides/bottom) flex container, `flex-wrap: wrap-reverse`, `align-items: flex-end`, `justify-content: center`, gap 7px, `overflow:hidden` (balls appear to "fill from the bottom"). Balls sorted largest-first so bigger balls settle to the bottom row.
    - Empty state: italic muted text, e.g. "Add your first happy moment" / "Nothing here yet — good."
  - Add button: pill, Caveat 17px bold, "+ Add happy moment" / "+ Add hurtful moment" (label reflects which jar), margin-top 14px.
- **Balls:** circles at 3 fixed diameters — Little 32px, Medium 46px, Big 62px. Each ball's hue is picked (deterministically, by hashing the entry id) from that jar's 4-color palette; then **lightness/saturation is adjusted by size**: Little → lighter + less saturated (`+8% lightness, ×0.72 chroma`), Medium → unchanged, Big → darker + richer (`-15% lightness, ×1.25 chroma`). Each ball has a small glossy radial-gradient highlight (white fading into the color, centered upper-left), a soft drop shadow, and a slight deterministic rotation (-7° to +7°) and vertical jitter (0-4px) for a hand-tossed look. Hovering shows a native tooltip with the entry's description + short date.

## Piggy Bank card (Shivali's tab only)
- **Purpose:** A running "apology fund" total that Vrushab manually adds to (or Shivali withdraws from) — NOT auto-tied to logging hurtful entries.
- **Layout:** Card, max-width 400px, centered, cream background `#fffaf2`, 3px dark border, asymmetric rounded corners (`26px 22px 28px 24px`), drop shadow. A small rotated "washi tape" rectangle decorates the top-left corner (`rgba(217,123,86,0.55)`, rotate -4deg).
- **Icon:** hand-drawn pig icon built from CSS shapes (rounded body, two triangular ears via `clip-path`, snout, nostrils, eye, blush, 2 front legs, a curled tail via a partial-border circle, and a coin-slot bar on top). All pink `#f0a9a0` fill with dark `#3d2c22` outlines, ~78×62px.
- **Text:** "Piggy Bank" (Caveat 20px bold) + "· Apology Fund" (Quicksand 12px, muted `#b08a63`). Below: big total in Caveat 38px bold, plus a small pill toggle button ("show ₹" / "show €") to flip currency display.
- **Actions row:** "+ Add" (tan pill), "− Remove" (blush pill), "History" (white pill, pushed right via `margin-left:auto`).

## Interactions & Behavior

### Tabs
Clicking "Shivali"/"Vrushab" switches `activeTab`. Shivali's palette and Vrushab's palette are entirely distinct hue families (see Design Tokens) so the two feel visually different at a glance. Piggy Bank only renders when `activeTab === 'shivali'`.

### Add/Edit entry modal
Opened by: a jar's "+ Add" button (new entry), or the Edit action in a "view entries" list (pre-filled edit).
- Overlay: fixed, full-screen, `rgba(61,44,34,0.38)` scrim; click outside the card closes it (click on the card itself does not, via stopPropagation).
- Fields: **Date** (native date input, defaults to today), **Description** (textarea, 3 rows, placeholder differs by jar — happy: "e.g. Made me laugh so hard at breakfast"; hurtful: "e.g. Left the dishes for me again"), **Intensity** (3 buttons: Little/Medium/Big, each with a colored dot preview sized 14/20/28px, selected state = solid border + tinted background), **Tag** (required — pill buttons for each tag in the tag list; selected pill fills with that tag's color).
- Validation: description must be non-empty; a tag must be selected. Inline error text in `#c0512f` if either is missing.
- Editing an existing entry shows a "Delete" text-link (left-aligned via `margin-right:auto`) next to Cancel/Save.
- Save writes to that person+jar's array; Delete removes it and closes the modal if it was open on that entry.

### View entries (separate per jar)
Two independent buttons/modals — "View happy entries" and "View hurtful entries" — each scoped to ONE jar of the current tab (not combined). Modal shows:
- A row of **tag filter chips**: "All" + each tag; selecting one filters the list client-side (no reload). "All" pill is dark/filled when active; tag pills use that tag's color when selected.
- List of entries, **newest date first**, each row: colored dot (jar's accent), date (long format, e.g. "Aug 3, 2026"), tag chip, size label, description text, and Edit/Delete text-buttons on the right.
- Empty state: "Nothing logged yet." (italic, muted).

### Piggy Bank modals
- **Add / Remove**: form with Date (defaults today), Amount (numeric, label shows current currency symbol), Note (free text, placeholder "What's this for?"). Amount is required and must be > 0. Submitting appends a signed history entry (add = positive, remove = negative) and closes the modal.
- **History**: read-only list, newest first — date, note, signed amount (green for add, rust-red for remove), Delete button per row (removes that history entry and recalculates the total, since total is always derived as `sum(history)`, never stored separately).
- **Currency toggle**: a small pill button flips between € and ₹ display everywhere (total + history rows). Internally, all amounts are stored in a canonical EUR-equivalent number; the ₹ view is simply `amount × 100` (a fixed illustrative rate, not live FX) — entering an amount while ₹ is selected divides by 100 before storing, so the total stays consistent regardless of which currency was active when each entry was made.

## State Management
Suggested shape (mirrors the prototype's React state):
```
{
  activeTab: 'shivali' | 'vrushab',
  data: {
    shivali: { happy: Entry[], hurtful: Entry[] },
    vrushab: { happy: Entry[], hurtful: Entry[] }
  },
  currency: 'EUR' | 'INR',
  piggyHistory: PiggyEntry[],   // total is always derived: sum(piggyHistory.amount)
  // transient UI state: which modal is open, form drafts, active filter, etc.
}

Entry = { id: string, date: 'YYYY-MM-DD', description: string, size: 'little'|'medium'|'big', tag: string }
PiggyEntry = { id: string, date: 'YYYY-MM-DD', amount: number /* signed, EUR-equivalent */, note: string }
```
- **No seed data** — every jar and the piggy bank start empty.
- Persist to `localStorage` (or a real backend, if the target app has one) so entries survive a reload — the prototype does not persist (in-memory only) since it lives in a design tool.
- Tag list is configurable (default: `Us, Work, Family, Money`) — treat as a simple string array/constant, not hardcoded per-component.

## Design Tokens

### Colors
- Background: `#fbf1e6` (cream) with a subtle dot-grain texture: `radial-gradient(circle, rgba(61,44,34,0.055) 1px, transparent 1.6px)`, 16px tile.
- Ink/text: `#3d2c22` (warm dark brown — used instead of pure black everywhere).
- Muted text: `#8a7362`; tertiary muted: `#b08a63`.
- Link/accent action color: `#c0512f` (hover `#8f3a1f`).
- Error text: `#c0512f`.
- Card surface: `#fffaf2`.
- Input border (idle): `#dccab6`.

**Shivali's palette** (pink/coral + dusty blue-lavender — distinct from Vrushab's):
- Happy balls: `oklch(82% 0.12 25)`, `oklch(76% 0.16 18)`, `oklch(85% 0.09 48)`, `oklch(70% 0.17 8)`
- Happy accent (lid/tag): `oklch(78% 0.13 22)`
- Hurtful balls: `oklch(80% 0.045 255)`, `oklch(76% 0.04 290)`, `oklch(74% 0.03 235)`, `oklch(68% 0.05 270)`
- Hurtful accent: `oklch(78% 0.045 260)`
- Tab accent (active): `oklch(74% 0.15 20)`

**Vrushab's palette** (sage-green happy, amber/gold hurtful — distinct hue range from Shivali's):
- Happy balls: `oklch(76% 0.05 165)`, `oklch(73% 0.045 190)`, `oklch(79% 0.03 150)`, `oklch(68% 0.05 175)`
- Happy accent: `oklch(75% 0.045 170)`
- Hurtful balls: `oklch(80% 0.13 75)`, `oklch(75% 0.15 65)`, `oklch(85% 0.10 92)`, `oklch(70% 0.16 55)`
- Hurtful accent: `oklch(76% 0.14 68)`
- Tab accent (active): `oklch(74% 0.14 70)`

**Ball size adjustment** (applied to whichever base hue is picked): Little = `lightness +8%, chroma ×0.72`; Medium = unchanged; Big = `lightness -15%, chroma ×1.25` (clamped to 40–94% lightness).

**Tag colors** (light chip backgrounds, `oklch(85% 0.08 <hue>)`): Us=25 (warm pink), Work=230 (blue), Family=100 (olive/green), Money=145 (teal-green). Any tag not in this map falls back to a hash-derived hue.

**Piggy Bank icon:** body/ears/legs fill `#f0a9a0`, snout fill `#f7bdb5`, blush `rgba(212,90,90,0.35)`, all outlines `#3d2c22` 2.5–3px.

### Typography
- Display/handwritten: **Caveat** (Google Font, weights 600/700) — used for the page title, tab labels, jar labels, buttons, modal titles, piggy bank total.
- Body/UI: **Quicksand** (Google Font, weights 500/600/700) — used for body copy, form inputs, small labels/captions.
- Scale used: 64px (page title) / 38px (piggy total) / 28px (modal title) / 26px (modal title, smaller) / 22px (tab) / 20px (jar label) / 17–19px (buttons) / 14–15px (body/inputs) / 12–13px (captions/labels) / 10.5–11px (chips).

### Spacing / Shape
- Border radius is intentionally **asymmetric** throughout (e.g. jar body `30px 30px 60px 60px / 30px 30px 46px 46px`, cards `26px 22px 28px 24px`) rather than uniform — part of the hand-drawn feel. Pills use `999px`.
- Borders are thick (2–5px) and dark (`#3d2c22`), always paired with a small offset drop shadow (e.g. `2px 3px 0 rgba(61,44,34,0.2)`) for a "cut paper / sticker" look rather than soft blurred shadows.
- Jar wrappers are rotated ±2deg; jar label tags rotated -2 to -3deg — slight, consistent tilt, not randomized per render.

## Assets
No external images. All illustration (jar, balls, piggy bank) is built from plain CSS shapes (divs with border-radius/clip-path/gradients) — no SVG, no icon libraries. Fonts are loaded from Google Fonts (Caveat, Quicksand).

## Screenshots
See `screenshots/` in this folder: main view (Shivali tab), Vrushab tab, the add-entry modal, and the piggy bank history modal.

## Files
- `Feelings Jars.dc.html` — main app: header, tabs, piggy bank card, all modals (add/edit entry, view entries + tag filter, piggy add/remove/history), and all state/logic.
- `Jar.dc.html` — the reusable jar component (mounted twice per tab: happy + hurtful), rendering the lid/neck/body/label/balls/add-button and the per-ball color/size logic.

Open either file directly in a browser to see it render (it's a self-contained runtime), or read the source directly — it's plain HTML/CSS with a small React-like logic class per file, so the structure and inline styles map 1:1 to what's described above.
